<?php

namespace Box\Spout\Common\Exception;

/**
 * Class InvalidArgumentException
 */
class InvalidArgumentException extends SpoutException
{
}
